# ChatBot_U1
This repository is created for all the code and documentation files regarding the chatbot made for use case 1. Use case one is a 1-1 chatbot created for customers of the hotel.


#How to use a git repo - 

Git checkout 
Git pull the new develop copy 
Then switch to develop in the bottom left corner 
Then select the new branch or existing branch you are working with 
Then merge with new develop branch you have pulled 
Then edit code 
Then save (check the white dot) 
Then git add . 
Then git commit . -m “the changes I have made…” 
Then git push 
Then I should go to bit buckets check the left tabs and select pull requests 
Then press create pull request on the top right 
Select source which is your branch and destination as develop 
Get the develop approved and merged 
After merging check airflow to see if your dag is broken in airflow.qa
Check in deployment and changes are being reflected 
Switch to master branch 
Git checkout master 
Git pull master 
Then press master at the left bottom corner and select the master branch I created or need to edit 
Then git merge master (to merge it to master) 
Then git cherry-pick (the code from the pull requests of the merged develop branch) 
The git push 
Check bit bucket and create a pull request 
To develop go to bitbucket and add a tag to the merged commit “bi-2022- month - date - v…”
Then go to data bricks bamboo and search by release tag name and then develop 



-----------------------------------------------------------------------------------------------------------------------

#this repo will have a folder with the code for the chatbot made for usecase 1. 
and will also include a file that can reffered to for running the code (i.e. documentation)

-----------------------------------------------------------------------------------------------------------------------